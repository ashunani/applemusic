# apple-playlist-downloader-webapp

Web app to download your favourite apple music playlist to mp3 directly!

> Open: https://appleplaylistdownloader.herokuapp.com/

> Paste your playlist link like:<br> https://music.apple.com/in/playlist/shubham/pl.u-GgA5klRUo9y91A0?ls

> Get all the songs direct download link to download from a single page!

> Download all in just one click is not possible as it'll spam all the songs download in single second.

> use https://github.com/Shubhamrawat5/apple-playlist-downloader to download all playlist songs automatically in single execute! (cli version)

## Web app Screenshot-

<img src="https://i.ibb.co/YhPyBLK/play1.png" width=800>

### Result:-

<img src="https://i.ibb.co/BPdJ97v/play2.png" width=800>
